#
# Copyright (c) 2017 Qualcomm Technologies International, Ltd.
# All rights reserved.
# Qualcomm Technologies International, Ltd. Confidential and Proprietary.
#
"""Kalimba Simulator (kalsim) instrument"""

import logging
import os
import subprocess
import sys
import threading
import time

from kats.framework.library.instrument import Instrument
from kats.framework.library.log import log_input, log_exception

INSTRUMENT = 'kalsim'
PATH = 'path'
FIRMWARE = 'firmware'
PORT = 'port'
CLIENT = 'client'
VERBOSE = 'verbose'
QUIET = 'quiet'
DOTS = 'dots'
DEBUG = 'debug'
DEBUG_PORT = 'debug_port'
CLOCK_SPEED = 'clock_speed'
CMDLINE_ARGS = 'cmdline_args'

DEFAULT_DEBUG_PORT = 31400


class Kalsim(Instrument):
    """kalimba simulator instrument.

    This instrument creates a kalimba simulator process, with control over the command line
    options. By default it starts kalsim as server for kalcmd2 and the debugger.

    Args:
        path (str): Full path to kalsim binary
        firmware (str): Full path to kalsim firmware file without file extension
            (as kalsim expects it)
        port (int): Port to use to connect to kalsim
        client (bool): Connect to kalcmd2 as client with port
        verbose (bool): Enable kalsim output of several messages to console
        quiet (bool): Disable banner and progress information
        dots (bool): Enable dot progress printing
        debug (bool): Enable kalsim to connect to debugger. kalsim will not run until the debugger
            connects and issues a run
        debug_port (int): port to be used by debugger
        clock_speed (int): Set default clockspeed of the Kalimba in MHz
        cmdline_args (list[str]): Addtional command-line arguments for kalsim
    """

    interface = 'kalsim'
    schema = {
        'type': 'array',
        'minItems': 1,
        'uniqueItems': True,
        'items': {
            'type': 'object',
            'required': [PATH, FIRMWARE, PORT],
            'properties': {
                PATH: {'type': 'string'},
                FIRMWARE: {'type': 'string'},
                PORT: {'type': 'integer'},
                CLIENT: {'type': 'boolean'},
                VERBOSE: {'type': 'boolean'},
                QUIET: {'type': 'boolean'},
                DOTS: {'type': 'boolean'},
                DEBUG: {'type': 'boolean'},
                DEBUG_PORT: {'type': 'integer', 'minimum': 0, 'maximum': 65535},
                CLOCK_SPEED: {'type': 'integer', 'minimum': 0},
                CMDLINE_ARGS: {
                    'type': 'array',
                    'minItems': 1,
                    'items': {
                        'type': 'string',
                    },
                },
            }
        }
    }

    def __init__(self, path, firmware, port, **kwargs):
        self._log = logging.getLogger(__name__) if not hasattr(self, '_log') else self._log
        self._log.info('init path:%s firmware:%s port:%s params:%s',
                       path, firmware, port, str(kwargs))

        self._path = path
        self._firmware = os.path.splitext(firmware)[0]
        self._port = port
        self._params = {}
        self._params[CLIENT] = kwargs.pop(CLIENT, False)
        self._params[VERBOSE] = kwargs.pop(VERBOSE, False)
        self._params[QUIET] = kwargs.pop(QUIET, False)
        self._params[DOTS] = kwargs.pop(DOTS, True)
        self._params[DEBUG] = kwargs.pop(DEBUG, False)
        self._params[DEBUG_PORT] = kwargs.pop(DEBUG_PORT, DEFAULT_DEBUG_PORT)
        self._params[CLOCK_SPEED] = kwargs.pop(CLOCK_SPEED, None)
        self._params[CMDLINE_ARGS] = kwargs.pop(CMDLINE_ARGS, [])
        self._proc = None  # kalsim process handler
        self._data_background_thread = None

        if kwargs:
            self._log.warning('parameters:%s unknown', str(kwargs))

    @log_input(logging.INFO)
    @log_exception
    def start(self):
        """Start kalsim

        This will start the kalsim binary

        Raises:
            RuntimeError: If the instrument is already started
        """
        if self._proc:
            raise RuntimeError('kalsim already started')

        # build command line arguments for kalsim binary
        args = [self._path, self._firmware]

        if self._params[CLIENT]:
            args += ['--kalcmd2-client', '127.0.0.1', str(self._port)]  # connect as client
        else:
            args += ['--kalcmd2', str(self._port)]  # wait for connection as server

        args += ['--non-interactive']  # disable stdin commands as otherwise it would capture stdin

        if self._params[DEBUG]:
            args.append('-d')
            if self._params[DEBUG_PORT]:
                args += ['--listenport', str(self._params[DEBUG_PORT])]

        if self._params[VERBOSE]:
            args += [
                '--kalcmd2-perf',  # enable performance monitoring
                '--kalcmd2-perf-print',  # enable performance printing per second
                '--visible-watchdog'  # print kalcmd2 watchdog to console
            ]

        if not self._params[DOTS]:
            args.append('--disable-dots')

        if self._params[CLOCK_SPEED] is not None:
            args += ['--clock-speed', str(self._params[CLOCK_SPEED])]

        args += self._params[CMDLINE_ARGS]

        self._log.info('starting kalsim %s', args)
        try:
            self._proc = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                          stderr=sys.stderr)
        except Exception as exc:
            self.stop()
            raise RuntimeError('unable to execute kalsim binary:%s' % (args)) from exc

        # create kalsim stdout polling thread
        self._log.info('creating kalsim stdout thread')
        self._data_background_thread = threading.Thread(target=self._stdout_thread, args=())
        self._data_background_thread.daemon = True
        self._data_background_thread.setName('kalsim background')
        self._data_background_thread.start()

    def check_started(self):
        """Check if instrument is connected to kalsim and ready for operation

        For it to be ready, a start should have been issued previously and kalsim binary should not
        have exited

        Returns:
            bool: kalsim started
        """
        return self._proc is not None

    @log_input(logging.INFO)
    def stop(self):
        """Close instrument."""
        if self._proc:
            self._proc.terminate()
            self._proc.wait()
            self._proc = None

            # wait for background thread to die
            while self._data_background_thread and self._data_background_thread.is_alive():
                time.sleep(0.01)
            self._data_background_thread = None

    @log_input(logging.INFO)
    @log_exception
    def set_port(self, port):
        """Change the port value

        This method can only be called if the instrument is not started

        Args:
            port (int): New port to use to connect to kalsim

        Raises:
            RuntimeError: If the instrument is started
        """
        if not self._proc:
            self._port = port
        else:
            raise RuntimeError('unable to change port while running')

    def get_debug(self):
        """Get debug parameter value

        Returns:
            bool: Debug enabled
        """
        return self._params[DEBUG]

    def _stdout_thread(self):
        """kalsim stdout monitor thread

        kalsim stdout is connected to a pipe. This thread is monitoring that pipe
        and generating log messages for everything that kalsim is outputing
        """
        self._log.debug('kalsim stdout thread starting')
        for line in iter(self._proc.stdout.readline, b''):
            self._log.info('kalsim stdout:%s', str(line.decode('utf-8')).rstrip('\r\n'))
        self._log.info('kalsim died, stdout thread exiting')
